# Basic Auto-scaling

This example provisions a basic auto-scaling configuration and group without policies.
