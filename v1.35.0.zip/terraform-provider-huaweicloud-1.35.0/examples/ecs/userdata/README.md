# ECS Instance With User Data

This example provisions an ecs instance with user data.
