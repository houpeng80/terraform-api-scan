# ECS Instance With Attached Network Interface

This example provisions an ecs instance with network interface attached.
