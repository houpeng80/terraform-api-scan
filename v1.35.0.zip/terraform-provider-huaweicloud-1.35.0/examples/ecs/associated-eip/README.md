# ECS Instance With EIP Associated

This example provisions an ecs instance with EIP associated.
