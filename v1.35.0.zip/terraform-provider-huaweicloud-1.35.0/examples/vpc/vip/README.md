# Basic VIP

This example provisions two ecs instances with a vip.
