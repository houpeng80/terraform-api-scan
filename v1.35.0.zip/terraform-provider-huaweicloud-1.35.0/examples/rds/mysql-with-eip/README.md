# MySQL instance with public IP

This example provisions a mysql instance with public IP.
