# Read Replica Instance

This example provisions a basic mysql instance and read replica instance.
