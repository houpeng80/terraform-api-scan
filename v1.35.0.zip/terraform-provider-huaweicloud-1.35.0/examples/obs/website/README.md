# OBS with Static Website Hosting

This example provisions a OBS with static website hosting.
