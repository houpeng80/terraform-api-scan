package flexibleengine

import (
	"fmt"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/v2/helper/resource"
	"github.com/hashicorp/terraform-plugin-sdk/v2/terraform"
)

func TestAccEcsFlavorsDataSource_basic(t *testing.T) {
	resourceName := "data.flexibleengine_compute_flavors_v2.this"

	resource.ParallelTest(t, resource.TestCase{
		PreCheck:  func() { testAccPreCheck(t) },
		Providers: testAccProviders,
		Steps: []resource.TestStep{
			{
				Config: testAccEcsFlavorsDataSource_basic,
				Check: resource.ComposeTestCheckFunc(
					testAccCheckEcsFlavorDataSourceID(resourceName),
					resource.TestCheckResourceAttrSet(resourceName, "flavors.#"),
				),
			},
		},
	})
}

func testAccCheckEcsFlavorDataSourceID(n string) resource.TestCheckFunc {
	return func(s *terraform.State) error {
		rs, ok := s.RootModule().Resources[n]
		if !ok {
			return fmt.Errorf("Can't find compute flavors data source: %s", n)
		}

		if rs.Primary.ID == "" {
			return fmt.Errorf("Compute Flavors data source ID not set")
		}

		return nil
	}
}

const testAccEcsFlavorsDataSource_basic = `
data "flexibleengine_compute_flavors_v2" "this" {
  performance_type = "normal"
  cpu_core         = 2
  memory_size      = 4
}
`
