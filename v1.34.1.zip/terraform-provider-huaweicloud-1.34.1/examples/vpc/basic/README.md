# Basic VPC and subnet

This example provisions a basic vpc and subnet.
