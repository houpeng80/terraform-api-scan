# Basic security group and rule

This example provisions a basic security group with default rules and two ingress rules:

* allow all inbound ICMP traffic
* allow all inbound traffic on 443 port
