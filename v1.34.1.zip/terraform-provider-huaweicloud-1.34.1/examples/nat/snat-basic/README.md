# Basic NAT gateway and snat rule

This example provisions a basic NAT gateway and snat rule.
