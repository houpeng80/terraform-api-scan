# Auto-scaling by CES alarm

This example provisions an auto-scaling group with CES scaling-up and scaling-down alarm policies.
