# Basic Cloud Container Engine (CCE)

This example provisions a basic CCE cluster and node.
