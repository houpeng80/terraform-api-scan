# Basic MySQL Instance

This example provisions a basic mysql instance as well as VPC, subnet and security group.
