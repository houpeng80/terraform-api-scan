# Basic MySQL Instance

This example provisions a basic mysql instance using the existing network resource.
