# ECS Instance In PrePaid Charging Mode

This example provisions an ecs instance in prepaid charging mode.
