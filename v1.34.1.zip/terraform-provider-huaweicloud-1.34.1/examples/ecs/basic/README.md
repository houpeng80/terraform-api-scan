# Basic ECS Instance

This example provisions a basic ecs instance.
