# ECS Instance With Attached Volume

This example provisions an ecs instance with volume attached.
