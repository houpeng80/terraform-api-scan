# Basic OBS

This example provisions a OBS and put a file.
