# Basic Elastic Load Balance (ELB)

This example provisions a basic ELB loadbalancer and listener along with two ECS web servers.
